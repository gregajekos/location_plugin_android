package com.tovarnaidej.creativio_location_plugin;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.location.Location;
import android.os.IBinder;
import android.widget.Toast;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import io.flutter.Log;
import io.flutter.plugin.common.EventChannel;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;
import io.flutter.plugin.common.PluginRegistry;
import io.flutter.plugin.common.PluginRegistry.Registrar;

/**
 * CreativioLocationPlugin
 */
public class CreativioLocationPlugin implements MethodCallHandler, EventChannel.StreamHandler {
    public static final String STARTLISTENING = "startlistening";


    // Used in checking for runtime permissions.
    private static final int REQUEST_PERMISSIONS_REQUEST_CODE = 34;

    // The BroadcastReceiver used to listen from broadcasts from the service.
    private MyReceiver myReceiver;

    // A reference to the service used to get location updates.
    private LocationUpdatesService mService = null;

    // Tracks the bound state of the service.
    private boolean mBound = false;


    /**
     * Plugin registration.
     */
    Activity context;
    MethodChannel methodChannel;
    EventChannel eventChannel;
    EventChannel.EventSink event;
    public BackgroundService gpsService;
    private final PluginRegistry.Registrar registrar;
    private BroadcastReceiver chargingStateChangeReceiver;

    public static void registerWith(final Registrar registrar) {


        setChannels(registrar);


        //setChannels(registrar);
    }

    public static void setChannels(Registrar registrar) {
        Log.d("perms", "perms checked");

        final MethodChannel channel = new MethodChannel(registrar.messenger(), "creativio_location_plugin");
        final EventChannel eventChannel =
                new EventChannel(registrar.messenger(), "creativio_location_plugin_stream");
        CreativioLocationPlugin instance = new CreativioLocationPlugin(registrar.activity(), channel, eventChannel, registrar);
        channel.setMethodCallHandler(instance);

        eventChannel.setStreamHandler(instance);
    }

    public CreativioLocationPlugin(Activity activity, MethodChannel methodChannel, EventChannel eventChannel, Registrar registrar) {
        this.context = activity;
        this.methodChannel = methodChannel;
        this.methodChannel.setMethodCallHandler(this);
        this.registrar = registrar;
    }

    @Override
    public void onMethodCall(MethodCall call, Result result) {
        if (call.method.equals("getPlatformVersion")) {
            result.success("Android " + android.os.Build.VERSION.RELEASE);
        } else {
            if (call.method.equals(STARTLISTENING)) {
                Dexter.withActivity(registrar.activity())
                        .withPermissions(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                        ).withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        /*if (!isMyServiceRunning(BackgroundService.class)) {

                            final Intent intent = new Intent(context, BackgroundService.class);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                context.startForegroundService(intent);
                            }
                            else
                            {
                                context.startService(intent);
                            }
                            context.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
                        }*/


                        // Bind to the service. If the service is in foreground mode, this signals to the service
                        // that since this activity is in the foreground, the service can exit foreground mode.
                        context.bindService(new Intent(context, LocationUpdatesService.class), mServiceConnection,
                                Context.BIND_AUTO_CREATE);
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        /* ... */
                        Log.d("perms", "perms confirmed?");
                    }
                }).check();

                result.success("Android " + android.os.Build.VERSION.RELEASE);
            } else {
                result.notImplemented();
            }

        }
    }

    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            LocationUpdatesService.LocalBinder binder = (LocationUpdatesService.LocalBinder) service;
            mService = binder.getService();
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mService = null;
            mBound = false;
        }
    };
    private ServiceConnection serviceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder service) {
            String name = className.getClassName();
            if (name.contains("BackgroundService")) {
                Log.i("", "service connected");

                gpsService = ((BackgroundService.LocationServiceBinder) service).getService();

                gpsService.startTracking();
            }
        }

        public void onServiceDisconnected(ComponentName className) {
            if (className.getClassName().equals("BackgroundService")) {
                gpsService = null;
            }
        }
    };

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    @java.lang.Override
    public void onListen(java.lang.Object o, EventChannel.EventSink eventSink) {
        Log.i("onlisten", "onlisten called");
        chargingStateChangeReceiver = createChargingStateChangeReceiver(eventSink);
        this.registrar
                .context()
                .registerReceiver(
                        chargingStateChangeReceiver, new IntentFilter(BackgroundService.INTENT_ACTION));

        LocalBroadcastManager.getInstance(context).registerReceiver(myReceiver,
                new IntentFilter(LocationUpdatesService.ACTION_BROADCAST));

    }

    @java.lang.Override
    public void onCancel(java.lang.Object o) {
        registrar.context().unregisterReceiver(chargingStateChangeReceiver);
        chargingStateChangeReceiver = null;
        LocalBroadcastManager.getInstance(context).unregisterReceiver(myReceiver);

    }

    private BroadcastReceiver createChargingStateChangeReceiver(final EventChannel.EventSink eventSink) {
        return new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                Map<String, Object> map = new HashMap<>();

                if (intent.hasExtra("lon")) {
                    Log.d("key", "1");
                    map.put("longitude", intent.getDoubleExtra("lon", 0));
                }
                if (intent.hasExtra("lat")) {
                    Log.d("key", "2");

                    map.put("latitude", intent.getDoubleExtra("lat", 0));
                }

                if (intent.hasExtra("alt")) {
                    Log.d("key", "3");

                    map.put("altitude", intent.getDoubleExtra("alt", 0));
                }

                if (intent.hasExtra("speed")) {
                    Log.d("key", "4");

                    map.put("speed", intent.getFloatExtra("speed", 0));
                }

                if (intent.hasExtra("acc")) {
                    Log.d("key", "5");

                    map.put("accuracy", intent.getFloatExtra("acc", 0));
                }

                if (intent.hasExtra("timestamp")) {
                    Log.d("key", "6 " + System.currentTimeMillis());

                    map.put("timestamp", System.currentTimeMillis());
                }

                eventSink.success(map);
            }
        };
    }

    /**
     * Receiver for broadcasts sent by {@link LocationUpdatesService}.
     */
    private class MyReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Location location = intent.getParcelableExtra(LocationUpdatesService.EXTRA_LOCATION);
            if (location != null) {
                Toast.makeText(context, Utils.getLocationText(location),
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

}
